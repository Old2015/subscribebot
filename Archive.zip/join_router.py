from aiogram import Router, types, F        # ← добавили F
import config, supabase_client, logging
from datetime import datetime, timezone

log = logging.getLogger(__name__)
join_router = Router()

# v3: без kwargs, фильтр ставим через F
@join_router.chat_join_request(F.chat.id == config.PRIVATE_GROUP_ID)
async def on_join_request(event: types.ChatJoinRequest):
    tg_id      = event.from_user.id
    link_used  = event.invite_link.invite_link if event.invite_link else None
    stored_link, stored_exp = supabase_client.get_invite(tg_id)

    allowed = (
        stored_link
        and stored_link == link_used
        and stored_exp
        and stored_exp > datetime.now(timezone.utc)
    )

    if allowed:
        await event.approve()
        supabase_client.clear_invite(tg_id)
        log.info("Join-request APPROVED for tg=%s", tg_id)
    else:
        await event.decline()
        log.warning("Join-request DECLINED for tg=%s (link mismatch)", tg_id)